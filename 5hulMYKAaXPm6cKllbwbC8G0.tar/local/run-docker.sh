#!/bin/bash

set -eu

docker run --rm --workdir /app -v `pwd`:/app --name amazon_linux_2 -ti amazonlinux:2.0.20190508 /bin/bash
