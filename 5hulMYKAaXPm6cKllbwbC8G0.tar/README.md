# 5hulMYKAaXPm6cKllbwbC8G0

## How to Use

Download the access log gz file to a local filepath inside this project (e.g. `./file/`)

Execute

1. `./.local/run-docker.sh`
2. `bin/01.sh <access_log_filepath>`
3. `bin/02.sh <access_log_filepath>`
4. `bin/03.sh <access_log_filepath>`

## Reference
https://serverfault.com/questions/139343/command-line-tools-to-analyze-apache-log-files
